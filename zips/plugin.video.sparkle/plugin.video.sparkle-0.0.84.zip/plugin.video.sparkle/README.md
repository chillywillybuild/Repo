This is a Kodi plugin that can be used to find acestream links. Note that you need Acestream and Plexus installed to use it.
