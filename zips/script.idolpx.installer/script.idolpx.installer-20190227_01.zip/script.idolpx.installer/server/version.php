<?php
	require 'auth/vendor/autoload.php';
	require 'auth/includes/config.php';
	require 'auth/includes/common.php';
	require 'auth/auth.php';
?>
{
    "config_version": "20181202_2151",
    "config_url": "http://yourdomain.com/kodi/kodi.20181202_2151.zip",
    "config_md5": "ec2d3ab7fe237122c37882258c7d4a7f",
    "test_version": "20181202_2151",
    "test_url": "http://yourdomain.com/kodi/kodi.20181202_2151.zip",
    "test_md5": "ec2d3ab7fe237122c37882258c7d4a7f",
    "kodi_version": "17.6",
    "kodi_url": "http://mirrors.kodi.tv/releases/android/arm/kodi-17.6-Krypton-armeabi-v7a.apk",
    "kodi_md5": ""
}